package org.outlander.views;

import android.graphics.Path;

class b {
    private static Path a;

    public static final Path a() {
        if (a == null) {
            a = new Path();
            a.moveTo(-0.7F, -0.7F);
            a.lineTo(0.0F, -3.0F);
            a.lineTo(0.7F, -0.7F);
            a.lineTo(3.0F, 0.0F);
            a.lineTo(0.7F, 0.7F);
            a.lineTo(0.0F, 3.0F);
            a.lineTo(-0.7F, 0.7F);
            a.lineTo(-3.0F, 0.0F);
            a.close();
        }
        return a;
    }
}
