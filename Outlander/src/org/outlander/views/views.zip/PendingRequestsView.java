package org.outlander.views;
import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import de.atlogis.tilemapview.aa;

public class PendingRequestsView extends TextView
{
  private aa a;
  private int b;
  private final Animation c;
  private final Animation d;
  private final String e;
  private final String f;
  private long g;
  private long h;
  private int i;
  private Handler j = new f(this);

  public PendingRequestsView(Context paramContext)
  {
    this(paramContext, null);
  }

  public PendingRequestsView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, "{0} Pending Request", "{0} Pending Requests");
  }

  public PendingRequestsView(Context paramContext, AttributeSet paramAttributeSet, Animation paramAnimation1, Animation paramAnimation2, String paramString1, String paramString2)
  {
    super(paramContext, paramAttributeSet);
    this.c = paramAnimation1;
    this.d = paramAnimation2;
    this.e = paramString1;
    this.f = paramString2;
    setVisibility(8);
  }

  public PendingRequestsView(Context paramContext, AttributeSet paramAttributeSet, String paramString1, String paramString2)
  {
    this(paramContext, paramAttributeSet, AnimationUtils.makeInAnimation(paramContext, true), AnimationUtils.makeOutAnimation(paramContext, false), paramString1, paramString2);
  }

  private void a(StringBuilder paramStringBuilder, String paramString, int paramInt)
  {
    for (int k = 0; ; k++)
    {
      if (k >= paramInt)
        return;
      paramStringBuilder.append(paramString);
    }
  }

  public void a(aa paramaa)
  {
    this.a = paramaa;
    this.j.sendEmptyMessageDelayed(0, 3000L);
  }
}
