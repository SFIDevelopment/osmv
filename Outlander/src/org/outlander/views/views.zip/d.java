package org.outlander.views;

import android.content.Context;
import android.graphics.Bitmap;

public class d extends i
{
  public d(Context paramContext, Bitmap paramBitmap1, Bitmap paramBitmap2)
  {
    super(paramContext, null, new e(paramContext, paramBitmap1, paramBitmap2), false);
  }
}
