package org.outlander.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View.MeasureSpec;

public class e extends c
{
  private final Bitmap e;
  private final Bitmap f;
  private final Paint g;
  private final int h;
  private final int i;
  private final float j;
  private final float k;
  private float l;
  private final int m;
  private final int n;

  public e(Context paramContext, Bitmap paramBitmap1, Bitmap paramBitmap2)
  {
    super(paramContext, true);
    this.e = paramBitmap1;
    this.f = paramBitmap2;
    this.g = new Paint();
    this.h = (paramBitmap1.getWidth() / 2);
    this.i = (paramBitmap1.getHeight() / 2);
    this.j = (paramBitmap2.getWidth() / 2);
    this.k = (paramBitmap2.getHeight() / 2);
    this.m = Math.max(paramBitmap1.getWidth(), paramBitmap2.getWidth());
    this.n = Math.max(paramBitmap1.getHeight(), paramBitmap2.getHeight());
  }

  public void a(int paramInt)
  {
  }

  public void b(int paramInt)
  {
    this.l = (-(paramInt % 360.0F));
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    int i2 = getWidth() / 2;
    int i1 = getHeight() / 2;
    paramCanvas.drawBitmap(this.e, i2 - this.h, i1 - this.i, this.g);
    paramCanvas.save(1);
    paramCanvas.rotate(this.l, i2, i1);
    paramCanvas.drawBitmap(this.f, i2 - this.j, i1 - this.k, this.g);
    paramCanvas.restore();
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i4 = View.MeasureSpec.getSize(paramInt1);
    int i3 = View.MeasureSpec.getSize(paramInt2);
    int i1 = View.MeasureSpec.getMode(paramInt1);
    int i2 = View.MeasureSpec.getMode(paramInt2);
    if (i1 != 1073741824)
      i4 = this.m;
    if (i2 != 1073741824)
      i3 = this.n;
    setMeasuredDimension(i4, i3);
  }
}
