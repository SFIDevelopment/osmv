package org.outlander.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;

public class TickView extends View
{
  private final Paint a = new Paint();
  private final Paint b;
  private int c;

  public TickView(Context paramContext)
  {
    this(paramContext, null);
  }

  public TickView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.a.setStyle(Paint.Style.FILL);
    this.b = new Paint();
    this.b.setColor(-1);
  }

  public void invalidate()
  {
    this.c = (1 + this.c);
    super.invalidate();
  }

  protected void onDraw(Canvas paramCanvas)
  {
    int i = getWidth();
    int j = getHeight();
    Paint localPaint = this.a;
    int k;
    if (this.c % 2 != 0)
      k = -16711936;
    else
      k = -65536;
    localPaint.setColor(k);
    paramCanvas.drawRect(0.0F, 0.0F, i, j, this.a);
    paramCanvas.drawText(Integer.toString(this.c), i / 2, j / 2, this.b);
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(View.MeasureSpec.getSize(paramInt1), View.MeasureSpec.getSize(paramInt2));
  }
}

