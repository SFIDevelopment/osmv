package org.outlander.views;

import java.util.List;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.media.SoundPool;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

public class RadarView extends SurfaceView
  implements SensorEventListener, SurfaceHolder.Callback
{
  private final Paint a = new Paint();
  private final Paint b;
  private final Paint c;
  private final Paint d;
  private final Paint e;
  private final Paint f;
  private SensorManager g;
  private Location h;
  private float i;
  private Location j;
  private Point k = new Point();
  private float l = 8.0F;
  private SoundPool m;
  private int n;
  private boolean o;
  private g p;
  private final AccelerateDecelerateInterpolator q = new AccelerateDecelerateInterpolator();
  private int r;

  public RadarView(Context paramContext)
  {
    this(paramContext, null);
  }

  public RadarView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext);
    this.a.setColor(-52429);
    this.a.setStyle(Paint.Style.FILL_AND_STROKE);
    this.b = new Paint();
    this.b.setAntiAlias(true);
    this.b.setStyle(Paint.Style.FILL_AND_STROKE);
    this.b.setStrokeWidth(2.0F);
    this.b.setColor(1429418973);
    this.c = new Paint();
    this.c.setColor(-2236963);
    this.c.setAntiAlias(true);
    this.c.setStyle(Paint.Style.STROKE);
    this.c.setStrokeWidth(3.0F);
    this.d = new Paint();
    this.d.setColor(-13382605);
    this.d.setAntiAlias(true);
    this.d.setStyle(Paint.Style.STROKE);
    this.d.setStrokeWidth(1.0F);
    this.e = new Paint();
    this.e.setColor(-1439437261);
    this.e.setAntiAlias(true);
    this.e.setStyle(Paint.Style.STROKE);
    this.e.setStrokeWidth(2.0F);
    this.f = new Paint();
    this.f.setColor(-1118482);
    this.f.setTextSize(10.0F);
    this.f.setTypeface(Typeface.SANS_SERIF);
    this.f.setTextAlign(Paint.Align.RIGHT);
    SurfaceHolder localSurfaceHolder = getHolder();
    localSurfaceHolder.addCallback(this);
    this.p = new g(this, localSurfaceHolder);
    setFocusable(true);
  }

  private Point a(Location paramLocation, Point paramPoint)
  {
    if ((this.h != null) && (paramLocation != null))
    {
      if (paramPoint == null)
        paramPoint = new Point();
      int i2 = getWidth() / 2;
      int i1 = getHeight() / 2;
      double d2 = paramLocation.getLatitude();
      double d3 = paramLocation.getLongitude();
      double d4 = this.h.getLatitude();
      double d1 = this.h.getLongitude();
      double d5 = 0.5D * i.a(d2, d1, d4, d1);
      if (d2 <= d4)
        d2 = d5;
      else
        d2 = -1.0D * d5;
      d4 = 0.5D * i.a(d4, d3, d4, d1);
      if (d3 >= d1)
        d1 = d4;
      else
        d1 = -1.0D * d4;
      i2 = (int)Math.round(d1 + i2);
      paramPoint.x = i2;
      i1 = (int)Math.round(d2 + i1);
      paramPoint.y = i1;
    }
    else
    {
      paramPoint = null;
    }
    return paramPoint;
  }

  private void a()
  {
    if (this.g != null)
      this.g.unregisterListener(this);
  }

  private int b()
  {
    if (this.r >= 10)
      this.r = 0;
    int i1 = 170 + (int)(85.0F * this.q.getInterpolation(this.r / 10.0F));
    this.r = (1 + this.r);
    return 0x33 | i1 << 16;
  }

  public void onAccuracyChanged(Sensor paramSensor, int paramInt)
  {
  }

  protected void onAttachedToWindow()
  {
    if (!isInEditMode())
    {
      this.g = ((SensorManager)getContext().getSystemService("sensor"));
      if (this.g != null)
      {
          List<Sensor> localList = this.g.getSensorList(3);
        if ((localList != null) && (localList.size() > 0))
          this.g.registerListener(this, (Sensor)localList.get(0), 2);
      }
      super.onAttachedToWindow();
    }
  }

  protected void onDetachedFromWindow()
  {
    a();
    if (this.g != null)
      this.g.unregisterListener(this);
    super.onDetachedFromWindow();
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i4 = View.MeasureSpec.getSize(paramInt1);
    int i2 = View.MeasureSpec.getSize(paramInt2);
    int i1 = View.MeasureSpec.getMode(paramInt1);
    int i3 = View.MeasureSpec.getMode(paramInt2);
    if ((i1 != 1073741824) || (i3 != 1073741824))
      i2 -= 2;
    setMeasuredDimension(i4, i2);
  }

  public void onSensorChanged(SensorEvent paramSensorEvent)
  {
    if ((3 == paramSensorEvent.sensor.getType()) && (paramSensorEvent.values != null) && (paramSensorEvent.values.length >= 1))
    {
      float f1 = paramSensorEvent.values[0];
      if (Math.abs(f1 - this.i) > 5.0F)
      {
        this.i = f1;
        postInvalidate();
      }
    }
  }

  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    (paramInt1 / 2);
    (paramInt2 / 2);
    Math.min(paramInt1, paramInt2);
  }

  public void surfaceChanged(SurfaceHolder paramSurfaceHolder, int paramInt1, int paramInt2, int paramInt3)
  {
    this.p.a(paramInt2, paramInt3);
  }

  public void surfaceCreated(SurfaceHolder paramSurfaceHolder)
  {
    this.p.a(true);
    this.p.start();
  }

  public void surfaceDestroyed(SurfaceHolder paramSurfaceHolder)
  {
    int i1 = 1;
    this.p.a(false);
    while (true)
    {
      if (i1 != 0);
      try
      {
        this.p.join();
        i1 = 0;
        continue;
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
      }
    }
  }
}
