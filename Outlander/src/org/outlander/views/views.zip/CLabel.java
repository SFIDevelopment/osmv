package org.outlander.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.widget.TextView;
import de.atlogis.tilemapview.ax;
import org.outlander.views.util.f;

public class CLabel extends i
{
  private String e = "";
  private int f = -1;

  public CLabel(Context paramContext)
  {
    this(paramContext, null);
  }

  public CLabel(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet, new l(paramContext));
    ((l)this.b).setTypeface(Typeface.MONOSPACE);
    ((l)this.b).setTextColor(-1);
    ((l)this.b).setText(this.e);
    ((l)this.b).setEllipsize(TextUtils.TruncateAt.END);
    ((l)this.b).setSingleLine();
    ((l)this.b).setBackgroundDrawable(null);
    ((l)this.b).setGravity(17);
  }

  public void aa(float paramFloat)
  {
    super.aa(paramFloat);
    ((l)this.b).setTextSize(paramFloat * ((l)this.b).getTextSize());
    ((l)this.b).a = true;
  }

  protected void a(AttributeSet paramAttributeSet)
  {
    TypedArray localTypedArray = getContext().obtainStyledAttributes(paramAttributeSet, ax.d);
    this.d = localTypedArray.getString(0);
    this.e = localTypedArray.getString(1);
    localTypedArray.recycle();
  }

  public void a(f paramf)
  {
    ((l)this.b).setText(paramf.b());
    if (this.f != paramf.a())
    {
      this.c.setText(paramf.c());
      this.f = paramf.a();
    }
  }

  public void aa(Object paramObject)
  {
    super.a(paramObject);
    if ((paramObject instanceof CLabel))
    {
      CLabel localCLabel = (CLabel)paramObject;
      ((l)this.b).setText(((l)localCLabel.b).getText());
      ((l)this.b).setTextSize(((l)localCLabel.b).getTextSize());
      ((l)this.b).setTypeface(((l)localCLabel.b).getTypeface());
      this.f = localCLabel.f;
    }
  }

  public void a(String paramString)
  {
    if (!this.e.equals(paramString))
      ((l)this.b).setText(paramString);
  }
}
