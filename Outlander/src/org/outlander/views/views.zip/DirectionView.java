package org.outlander.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import de.atlogis.tilemapview.ax;
import de.atlogis.tilemapview.util.b;
import de.atlogis.tilemapview.util.f;

public class DirectionView extends c
  implements h
{
  private final Path e;
  private final Point f;
  private final Paint g;
  private final Paint h;
  private final Paint i;
  private int j = 12;
  private int k;
  private int l;
  private f m;
  private boolean n = true;
  private boolean o;
  private float p = 1.0F;
  private RectF q = new RectF();

  public DirectionView(Context paramContext)
  {
    this(paramContext, null);
  }

  public DirectionView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, false);
  }

  public DirectionView(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean)
  {
    super(paramContext, paramBoolean);
    if (paramAttributeSet != null)
      a(paramAttributeSet);
    this.g = new Paint();
    this.g.setColor(-7829368);
    this.g.setAntiAlias(true);
    this.g.setStyle(Paint.Style.STROKE);
    this.g.setStrokeWidth(0.5F);
    this.h = new Paint();
    this.h.setAntiAlias(true);
    this.h.setColor(-7829368);
    this.h.setTextAlign(Paint.Align.CENTER);
    this.h.setTextSize(10.0F);
    this.i = new Paint();
    this.i.setAntiAlias(true);
    this.i.setTextAlign(Paint.Align.CENTER);
    this.i.setTextSize(this.j);
    this.i.setColor(-65794);
    this.e = new Path();
    this.e.moveTo(6.0F, 10.0F);
    this.e.lineTo(12.0F, 0.0F);
    this.e.lineTo(18.0F, 10.0F);
    this.e.lineTo(14.0F, 10.0F);
    this.e.lineTo(14.0F, 22.0F);
    this.e.lineTo(10.0F, 22.0F);
    this.e.lineTo(10.0F, 10.0F);
    this.e.close();
    this.f = new Point(12, 12);
  }

  private void a(AttributeSet paramAttributeSet)
  {
    TypedArray localTypedArray = getContext().obtainStyledAttributes(paramAttributeSet, ax.e);
    this.j = localTypedArray.getInt(0, this.j);
    localTypedArray.recycle();
  }

  public void a(float paramFloat)
  {
  }

  public void a(int paramInt)
  {
    this.l = paramInt;
    if (!this.o)
    {
      this.g.setStyle(Paint.Style.FILL);
      this.g.setColor(-16014856);
      this.o = true;
    }
  }

  public void a(f paramf)
  {
    this.m = paramf;
  }

  public void a(Object paramObject)
  {
    if ((paramObject instanceof DirectionView))
    {
      DirectionView localDirectionView = (DirectionView)paramObject;
      this.a = localDirectionView.a;
      if (localDirectionView.o)
        a(localDirectionView.l);
      this.k = localDirectionView.k;
    }
  }

  public void b(int paramInt)
  {
    this.k = (-paramInt);
  }

  public void c(int paramInt)
  {
    this.j = paramInt;
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    int i2 = getWidth();
    int i1 = getHeight();
    i2 /= 2;
    int i3 = i1 / 2;
    paramCanvas.save(1);
    paramCanvas.translate(i2 - this.f.x, i3 - this.f.y);
    paramCanvas.scale(this.p, this.p, this.f.x, this.f.y);
    paramCanvas.rotate(this.k + this.l, this.f.x, this.f.y);
    paramCanvas.drawPath(this.e, this.g);
    paramCanvas.restore();
    if (this.o)
    {
      if ((this.n) && (this.m != null))
        paramCanvas.drawText(this.m.toString(), i2, i1 - 2, this.i);
    }
    else
    {
      paramCanvas.save(1);
      paramCanvas.translate(i2, i3);
      paramCanvas.scale(this.p, this.p, 0.0F, 0.0F);
      paramCanvas.drawText("?", 0.0F, 0.0F, this.h);
      paramCanvas.restore();
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i4 = View.MeasureSpec.getSize(paramInt1);
    int i3 = View.MeasureSpec.getSize(paramInt2);
    int i2 = View.MeasureSpec.getMode(paramInt1);
    int i5 = View.MeasureSpec.getMode(paramInt2);
    this.e.computeBounds(this.q, true);
    int i1 = (int)(this.p * Math.ceil(Math.max(this.q.width(), this.q.height())));
    if (i2 != 1073741824)
      i4 = i1;
    if (i5 != 1073741824)
      i3 = i1;
    setMeasuredDimension(i4, i3);
  }

  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    boolean bool = true;
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    this.e.computeBounds(this.q, bool);
    double d = Math.ceil(Math.max(this.q.width(), this.q.height()));
    this.p = (0.8F * (float)(Math.min(paramInt1, paramInt2) / d));
    float f1 = 3.0F * this.p;
    if (f1 <= b.a(getContext(), 10))
      bool = false;
    this.n = bool;
    if (this.n)
      this.i.setTextSize(f1);
  }
}
