package org.outlander.views;

import java.util.HashMap;
import java.util.List;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

abstract class c extends View implements SensorEventListener, a {
    protected boolean       a;
    protected SensorManager b;
    protected int           c = -1;
    protected boolean       d;
    private final TextPaint e;
    private HashMap         f = new HashMap();

    c(Context paramContext, boolean paramBoolean) {
        super(paramContext);
        this.a = paramBoolean;
        this.e = new TextPaint();
        this.e.setAntiAlias(true);
        this.e.setStyle(Paint.Style.FILL);
        this.e.setColor(15658734);
    }

    private int cc() {
        int i;
        switch (this.c) {
            default:
                i = -1442788352;
                break;
            case 0:
                i = -1426128896;
                break;
            case 1:
                i = -1429458176;
                break;
            case 2:
                i = -1432787456;
        }
        return i;
    }

    private StaticLayout cc(int paramInt) {
        Object localObject;
        if (this.f.containsKey(Integer.valueOf(this.c))) {
            localObject = (StaticLayout) this.f.get(Integer.valueOf(this.c));
        } else {
            localObject = d(this.c);
            localObject = new StaticLayout((CharSequence) localObject, 0,
                    ((String) localObject).length(), this.e, paramInt,
                    Layout.Alignment.ALIGN_CENTER, 1.0F, 1.0F, true,
                    TextUtils.TruncateAt.MIDDLE, paramInt);
            this.f.put(Integer.valueOf(this.c), localObject);
        }
        return (StaticLayout) localObject;
    }

    private String d(int paramInt) {
        String str;
        switch (paramInt) {
            default:
                str = d.a(getContext(), i.p);
                break;
            case 0:
                str = d.a(getContext(), i.d);
                break;
            case 1:
                str = d.a(getContext(), i.b);
                break;
            case 2:
                str = d.a(getContext(), i.c);
                break;
            case 3:
                str = d.a(getContext(), i.a);
        }
        return str;
    }

    protected void a(Canvas paramCanvas) {
        if ((this.c != -1) && (this.c <= 2)) {
            int j = getWidth();
            StaticLayout localStaticLayout = cc(j);
            if (localStaticLayout != null) {
                int i = getHeight();
                this.e.setColor(cc());
                int k = i - localStaticLayout.getHeight();
                paramCanvas.drawRect(0.0F, k - 5, j, i, this.e);
                this.e.setColor(-1118482);
                paramCanvas.save(1);
                paramCanvas.translate(0.0F, k - 2);
                localStaticLayout.draw(paramCanvas);
                paramCanvas.restore();
            }
        }
    }

    public void a(f paramf) {
    }

    public boolean a() {
        return false;
    }

    public boolean b() {
        return this.a;
    }

    public void onAccuracyChanged(Sensor paramSensor, int paramInt) {
        if (3 == paramSensor.getType())
            this.c = paramInt;
    }

    protected void onAttachedToWindow() {
        if ((!isInEditMode()) && (this.a)) {
            this.b = ((SensorManager) getContext().getSystemService("sensor"));
            if (this.b != null) {
                List localList = this.b.getSensorList(3);
                if ((localList != null) && (localList.size() > 0))
                    this.b.registerListener(this, (Sensor) localList.get(0), 3);
            }
            super.onAttachedToWindow();
        }
    }

    protected void onDetachedFromWindow() {
        if (this.b != null)
            this.b.unregisterListener(this);
        super.onDetachedFromWindow();
    }

    public void onSensorChanged(SensorEvent paramSensorEvent) {
        if ((paramSensorEvent != null) && (paramSensorEvent.sensor != null)
                && (3 == paramSensorEvent.sensor.getType())
                && (paramSensorEvent.values != null)
                && (paramSensorEvent.values.length >= 1)) {
            float f1 = paramSensorEvent.values[0];
            this.c = paramSensorEvent.accuracy;
            b((int) f1);
            if (!this.d)
                postInvalidate();
        }
    }

    protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3,
            int paramInt4) {
        super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
        this.f = new HashMap();
    }
}
