package org.outlander.views;

import android.content.Context;

public class k extends i
{
  public k(Context paramContext)
  {
    super(paramContext, null, new FlatCompassView(paramContext), false);
    ((FlatCompassView)c()).setPadding(0, 2, 0, 0);
  }

  public void a(Object paramObject)
  {
    super.a(paramObject);
    if ((paramObject instanceof k))
      ((FlatCompassView)this.b).a(((k)paramObject).b);
  }
}
