package org.outlander.views;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import de.atlogis.tilemapview.ay;
import de.atlogis.tilemapview.util.g;
import de.atlogis.tilemapview.util.i;

public class FlatCompassView extends c
  implements h
{
  private int e;
  private int f;
  private final Paint g = new Paint();
  private final Paint h;
  private final Paint i;
  private final Paint j;
  private float k = 16.0F;
  private int l;
  private int m;
  private int n;
  private int o;
  private boolean p;
  private boolean q = true;
  private final Drawable r;

  public FlatCompassView(Context paramContext)
  {
    this(paramContext, null);
  }

  public FlatCompassView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, true);
    this.g.setColor(-5592406);
    this.g.setStrokeWidth(2.0F);
    this.g.setTextAlign(Paint.Align.CENTER);
    this.g.setTypeface(Typeface.MONOSPACE);
    this.g.setTextSize(10.0F);
    this.h = new Paint();
    this.h.setColor(-7829368);
    this.h.setStrokeWidth(1.0F);
    this.i = new Paint();
    this.i.setColor(-3355444);
    this.i.setAntiAlias(true);
    this.i.setStrokeWidth(2.0F);
    this.i.setTextAlign(Paint.Align.CENTER);
    Typeface localTypeface = Typeface.create(Typeface.MONOSPACE, 1);
    this.i.setTypeface(localTypeface);
    this.j = new Paint();
    this.j.setColor(-1186541);
    this.j.setStyle(Paint.Style.STROKE);
    this.j.setAntiAlias(true);
    this.j.setStrokeWidth(2.0F);
    this.r = paramContext.getResources().getDrawable(ay.a);
  }

  private void a(Canvas paramCanvas, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 % 90 != 0)
      paramCanvas.drawText(Integer.toString(i.b(paramInt1)), paramInt2, paramInt3 + 3, this.g);
    else
      paramCanvas.drawText(g.e(paramInt1), paramInt2, paramInt3 + this.k / 3.0F, this.i);
  }

  private void a(Canvas paramCanvas, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    for (int i3 = paramInt1 + 10; ; i3 += 10)
    {
      if (i3 >= paramInt1 + 30)
      {
        int i1 = c(paramInt1 - this.n);
        paramCanvas.drawLine(i1, paramInt2, i1, paramInt2 + paramInt4, this.g);
        return;
      }
      int i2 = c(i3 - this.n);
      paramCanvas.drawLine(i2, paramInt2, i2, paramInt2 + paramInt3, this.h);
    }
  }

  private void b(Canvas paramCanvas)
  {
    int i1 = d(this.o);
    if (i1 - 10 >= 0)
    {
      if (i1 + 10 <= paramCanvas.getWidth())
      {
        this.j.setColor(-1186541);
      }
      else
      {
        i1 = -10 + paramCanvas.getWidth();
        this.j.setColor(-60653);
      }
    }
    else
    {
      i1 = 10;
      this.j.setColor(-60653);
    }
    paramCanvas.drawCircle(i1, 12.0F, 10.0F, this.j);
  }

  private int c(int paramInt)
  {
    return (int)((paramInt + 90) * (this.e / 180.0D));
  }

  private int d(int paramInt)
  {
    return (int)((paramInt + 90 - this.l) * (this.e / 180.0D));
  }

  public void aa(float paramFloat)
  {
  }

  public void a(int paramInt)
  {
    this.p = true;
    this.o = i.b(paramInt);
  }

  public void aa(Object paramObject)
  {
    if ((paramObject instanceof FlatCompassView))
    {
      FlatCompassView localFlatCompassView = (FlatCompassView)paramObject;
      this.a = localFlatCompassView.a;
      this.l = localFlatCompassView.l;
      this.m = localFlatCompassView.m;
      this.n = localFlatCompassView.n;
      this.o = localFlatCompassView.o;
      this.p = localFlatCompassView.p;
    }
  }

  public void b(int paramInt)
  {
    this.l = i.b(paramInt);
    this.n = (this.l % 30);
    this.m = (30 * (this.l / 30));
  }

  protected void onDraw(Canvas paramCanvas)
  {
    this.e = getWidth();
    this.f = getHeight();
    for (int i1 = -90; ; i1 += 30)
    {
      if (i1 > 90)
      {
        paramCanvas.drawLine(0.0F, 0.0F, this.e, 0.0F, this.h);
        paramCanvas.drawLine(0.0F, -1 + this.f, this.e, -1 + this.f, this.h);
        paramCanvas.drawLine(this.e / 2, 0.0F, this.e / 2, this.f, this.g);
        if (this.p)
          b(paramCanvas);
        this.r.setBounds(0, 0, this.e, this.f);
        this.r.draw(paramCanvas);
        if (this.q)
          a(paramCanvas);
        return;
      }
      a(paramCanvas, i1, 0, 4, 10);
      int i2 = this.f;
      a(paramCanvas, i1, i2, -4, -10);
      i2 = c(i1 - this.n);
      a(paramCanvas, i1 + this.m, i2, this.f / 2);
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i3 = View.MeasureSpec.getSize(paramInt1);
    int i2 = View.MeasureSpec.getSize(paramInt2);
    int i1 = View.MeasureSpec.getMode(paramInt1);
    int i4 = View.MeasureSpec.getMode(paramInt2);
    if (i1 != 1073741824)
      i3 = 240;
    if (i4 != 1073741824)
      i2 = 40;
    setMeasuredDimension(i3, i2);
  }

  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    int i1 = Math.min(paramInt1, paramInt2);
    float f1 = Math.min(16.0F, Math.max(8.0F, 0.2F * i1));
    this.g.setTextSize(f1);
    this.k = Math.max(16.0F, 0.4F * i1);
    this.i.setTextSize(this.k);
  }
}
