package org.outlander.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public abstract class i extends LinearLayout implements h {
    protected TextView a;
    protected View     b;
    protected TextView c;
    protected String   d = "";

    public i(Context paramContext, AttributeSet paramAttributeSet,
            View paramView) {
        this(paramContext, paramAttributeSet, paramView, true, false);
    }

    public i(Context paramContext, AttributeSet paramAttributeSet,
            View paramView, boolean paramBoolean) {
        this(paramContext, paramAttributeSet, paramView, paramBoolean, false);
    }

    public i(Context paramContext, AttributeSet paramAttributeSet,
            View paramView, boolean paramBoolean1, boolean paramBoolean2) {
        super(paramContext, paramAttributeSet);
        setOrientation(1);
        if (paramAttributeSet != null)
            a(paramAttributeSet);
        setWeightSum(4.0F);
        this.a = new TextView(paramContext);
        this.a.setTextSize(1, 11.0F);
        this.a.setSingleLine();
        this.a.setTypeface(Typeface.SANS_SERIF);
        this.a.setTextColor(-3355444);
        this.a.setText(this.d);
        this.a.setBackgroundDrawable(null);
        this.a.setPadding(4, 0, 0, 0);
        LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(
                -2, -2);
        localLayoutParams1.weight = 1.0F;
        addView(this.a, localLayoutParams1);
        this.b = paramView;
        paramView.setBackgroundDrawable(null);
        int i;
        if (!paramBoolean2)
            i = -1;
        else
            i = -2;
        LinearLayout.LayoutParams localLayoutParams3 = new LinearLayout.LayoutParams(
                i, -2);
        if (paramBoolean2)
            localLayoutParams3.gravity = 1;
        float f;
        if (!paramBoolean1)
            f = 3.0F;
        else
            f = 2.0F;
        localLayoutParams3.weight = f;
        addView(paramView, localLayoutParams3);
        if (paramBoolean1) {
            this.c = new TextView(paramContext);
            this.c.setTextSize(1, 12.0F);
            this.c.setSingleLine();
            this.c.setTypeface(Typeface.SANS_SERIF);
            this.c.setTextColor(-3355444);
            this.c.setBackgroundDrawable(null);
            this.c.setPadding(0, 0, 4, 0);
            this.c.setGravity(85);
            LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(
                    -1, -2);
            localLayoutParams2.weight = 1.0F;
            addView(this.c, localLayoutParams2);
        }
    }

    public TextView a() {
        return this.a;
    }

    public void aa(float paramFloat) {
        this.a.setTextSize(paramFloat * this.a.getTextSize());
        if (this.c != null)
            this.c.setTextSize(paramFloat * this.c.getTextSize());
    }

    protected void a(AttributeSet paramAttributeSet) {
        TypedArray localTypedArray = getContext().obtainStyledAttributes(
                paramAttributeSet, ax.d);
        this.d = localTypedArray.getString(0);
        localTypedArray.recycle();
    }

    protected void a(f paramf) {
        this.c.setText(paramf.c());
    }

    public void aa(Object paramObject) {
        if ((paramObject instanceof i)) {
            i locali = (i) paramObject;
            this.a.setText(locali.a.getText());
            this.a.setTextSize(locali.a.getTextSize());
            if (this.c != null) {
                this.c.setText(locali.c.getText());
                this.c.setTextSize(locali.c.getTextSize());
            }
        }
    }

    public TextView b() {
        return this.c;
    }

    public View c() {
        return this.b;
    }

    protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3,
            int paramInt4) {
        super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    }
}
