package org.outlander.views;

public abstract interface h
{
  public abstract void aa(float paramFloat);

  public abstract void aa(Object paramObject);
}
