package org.outlander.views;

import android.os.Handler;
import android.os.Message;
import android.view.animation.OvershootInterpolator;

class j extends Handler
{
  int a;
  int b;
  int c;
  private final OvershootInterpolator e = new OvershootInterpolator();

  public void handleMessage(Message paramMessage)
  {
    if (this.a < 15)
    {
      float f = this.a / 15.0F;
      f = this.e.getInterpolation(f);
      CompassView.a(this.d, this.b + (int)(f * this.c));
      this.a = (1 + this.a);
      this.d.invalidate();
    }
    sendEmptyMessageDelayed(0, 10L);
  }
}
