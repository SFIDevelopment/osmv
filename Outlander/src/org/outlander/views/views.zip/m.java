package org.outlander.views;

import android.content.Context;
import de.atlogis.tilemapview.util.b;

public class m extends i
{
  public m(Context paramContext)
  {
    super(paramContext, null, new DirectionView(paramContext, null, false), false);
    int i = b.b(paramContext, 12);
    ((DirectionView)c()).c(i);
  }

  public void a(Object paramObject)
  {
    super.a(paramObject);
    if ((paramObject instanceof m))
      ((DirectionView)this.b).a(((m)paramObject).b);
  }
}
