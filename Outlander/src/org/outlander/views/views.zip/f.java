package org.outlander.views;

import android.os.Handler;
import android.os.Message;
import de.atlogis.tilemapview.aa;
import java.text.MessageFormat;

class f extends Handler
{
  f(PendingRequestsView paramPendingRequestsView)
  {
  }

  public void handleMessage(Message paramMessage)
  {
    int i = PendingRequestsView.a(this.a).d();
    String str;
    if (i != 1)
      str = PendingRequestsView.c(this.a);
    else
      str = PendingRequestsView.b(this.a);
    Object localObject = new Object[1];
    localObject[0] = Integer.valueOf(i);
    localObject = new StringBuilder(MessageFormat.format(str, localObject));
    PendingRequestsView.a(this.a, (1 + PendingRequestsView.d(this.a)) % 4);
    PendingRequestsView.a(this.a, (StringBuilder)localObject, ".", PendingRequestsView.d(this.a));
    PendingRequestsView.a(this.a, (StringBuilder)localObject, " ", 3 - PendingRequestsView.d(this.a));
    this.a.setText(((StringBuilder)localObject).toString());
    if (i != PendingRequestsView.e(this.a))
    {
      if (i <= 0)
      {
        if (System.currentTimeMillis() - PendingRequestsView.h(this.a) <= 2000L)
        {
          PendingRequestsView.b(this.a, System.currentTimeMillis());
        }
        else
        {
          this.a.startAnimation(PendingRequestsView.i(this.a));
          this.a.setVisibility(8);
        }
      }
      else
      {
        long l = System.currentTimeMillis() - PendingRequestsView.f(this.a);
        if ((this.a.getVisibility() != 8) || (l <= 2000L))
        {
          PendingRequestsView.a(this.a, System.currentTimeMillis());
        }
        else
        {
          this.a.setVisibility(0);
          this.a.startAnimation(PendingRequestsView.g(this.a));
        }
      }
      PendingRequestsView.b(this.a, i);
    }
    PendingRequestsView.j(this.a).sendEmptyMessageDelayed(0, 1000L);
  }
}
