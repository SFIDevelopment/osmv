package org.outlander.views;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.widget.TextView;

class l extends TextView
{
  boolean a;
  private final int b;

  l(Context paramContext)
  {
    this(paramContext, null);
  }

  l(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.b = (int)(0.5F + 24.0F * paramContext.getResources().getDisplayMetrics().density);
  }

  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (!this.a)
    {
      float f = 0.66F * paramInt2;
      if (f <= this.b)
        f = this.b;
      setTextSize(0, f);
    }
  }
}
