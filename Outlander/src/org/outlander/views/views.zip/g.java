package org.outlander.views;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.location.Location;
import android.media.SoundPool;
import android.view.SurfaceHolder;
import de.atlogis.tilemapview.util.f;

class g extends Thread
{
  private final SurfaceHolder b;
  private boolean c = true;
  private int d;
  private int e;
  private final Paint f;

  g(RadarView paramRadarView, SurfaceHolder paramSurfaceHolder)
  {
    this.b = paramSurfaceHolder;
    this.f = new Paint();
    this.f.setColor(-16777216);
    this.f.setStyle(Paint.Style.FILL);
  }

  private void a(Canvas paramCanvas)
  {
    int j = this.d / 2;
    int i = this.e / 2;
    paramCanvas.drawRect(0.0F, 0.0F, this.d, this.e, this.f);
    paramCanvas.save(1);
    paramCanvas.rotate(360.0F - RadarView.b(this.a), j, i);
    paramCanvas.drawCircle(j, i, 8.0F, RadarView.c(this.a));
    paramCanvas.drawCircle(j, i, 16.0F, RadarView.c(this.a));
    paramCanvas.drawCircle(j, i, 24.0F, RadarView.c(this.a));
    paramCanvas.drawCircle(j, i, 32.0F, RadarView.c(this.a));
    paramCanvas.drawLine(j, 0.0F, j, i - 8, RadarView.c(this.a));
    paramCanvas.drawLine(j, i + 8, j, this.e, RadarView.c(this.a));
    paramCanvas.drawLine(0.0F, i, j - 8, i, RadarView.c(this.a));
    paramCanvas.drawLine(j + 8, i, this.d, i, RadarView.c(this.a));
    if ((RadarView.d(this.a) != null) && (RadarView.e(this.a) != null))
    {
      RadarView.f(this.a).setColor(-1439437261);
      paramCanvas.drawCircle(j, i, RadarView.a(this.a), RadarView.f(this.a));
      RadarView.f(this.a).setColor(-1442792704);
      paramCanvas.drawCircle(j, i, 4.0F + RadarView.a(this.a), RadarView.f(this.a));
      if (RadarView.a(this.a) > 12.0F)
        paramCanvas.drawCircle(j, i, RadarView.a(this.a) - 4.0F, RadarView.f(this.a));
      float f2;
      if ((!RadarView.d(this.a).hasAccuracy()) || (RadarView.d(this.a).getAccuracy() <= 8.0F))
        f2 = 8.0F;
      else
        f2 = RadarView.d(this.a).getAccuracy();
      int m = (int)f2;
      paramCanvas.drawCircle(j, i, m, RadarView.g(this.a));
      RadarView.a(this.a, RadarView.a(this.a, RadarView.e(this.a), RadarView.h(this.a)));
      if ((RadarView.h(this.a).x < 0) || (RadarView.h(this.a).x > this.d) || (RadarView.h(this.a).y < 0) || (RadarView.h(this.a).y > this.e))
      {
        paramCanvas.rotate(180.0F + RadarView.e(this.a).bearingTo(RadarView.d(this.a)), j, i);
        paramCanvas.drawLine(j, 2.0F, j - 6, 8.0F, RadarView.n(this.a));
        paramCanvas.drawLine(j, 2.0F, j + 6, 8.0F, RadarView.n(this.a));
      }
      else
      {
        if ((!RadarView.i(this.a)) && (RadarView.j(this.a) != null))
        {
          RadarView.j(this.a).play(RadarView.k(this.a), 1.0F, 1.0F, 1, 0, 1.0F);
          RadarView.a(this.a, true);
        }
        int k = RadarView.l(this.a);
        float f1 = 4.0F;
        if ((!RadarView.d(this.a).hasAccuracy()) || (RadarView.d(this.a).getAccuracy() <= 8.0F))
        {
          RadarView.m(this.a).setColor(k | 0xFF000000);
        }
        else
        {
          f1 = (float)(0.5D * RadarView.d(this.a).getAccuracy());
          RadarView.m(this.a).setColor(k | 0xAA000000);
        }
        paramCanvas.drawCircle(RadarView.h(this.a).x, RadarView.h(this.a).y, f1, RadarView.m(this.a));
      }
      paramCanvas.restore();
      Object localObject = de.atlogis.tilemapview.util.g.a(RadarView.d(this.a).distanceTo(RadarView.e(this.a)), true).toString();
      RadarView.o(this.a).setTextAlign(Paint.Align.RIGHT);
      paramCanvas.drawText((String)localObject, -2 + this.d, -8 + this.e, RadarView.o(this.a));
      if (RadarView.d(this.a).hasAccuracy())
      {
        RadarView.o(this.a).setTextAlign(Paint.Align.LEFT);
        localObject = new StringBuilder();
        ((StringBuilder)localObject).append('±');
        ((StringBuilder)localObject).append(RadarView.d(this.a).getAccuracy());
        paramCanvas.drawText(((StringBuilder)localObject).toString(), 2.0F, 14.0F, RadarView.o(this.a));
      }
    }
  }

  void a(int paramInt1, int paramInt2)
  {
    synchronized (this.b)
    {
      this.d = paramInt1;
      this.e = paramInt2;
      return;
    }
  }

  void a(boolean paramBoolean)
  {
    this.c = paramBoolean;
  }

  // ERROR //
  public void run()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 24	de/atlogis/tilemapview/views/g:c	Z
    //   4: ifeq +115 -> 119
    //   7: aload_0
    //   8: getfield 26	de/atlogis/tilemapview/views/g:b	Landroid/view/SurfaceHolder;
    //   11: aconst_null
    //   12: invokeinterface 230 2 0
    //   17: astore_1
    //   18: aload_1
    //   19: astore_1
    //   20: aload_0
    //   21: getfield 26	de/atlogis/tilemapview/views/g:b	Landroid/view/SurfaceHolder;
    //   24: astore_3
    //   25: aload_3
    //   26: monitorenter
    //   27: aload_0
    //   28: getfield 19	de/atlogis/tilemapview/views/g:a	Lde/atlogis/tilemapview/views/RadarView;
    //   31: invokestatic 96	de/atlogis/tilemapview/views/RadarView:a	(Lde/atlogis/tilemapview/views/RadarView;)F
    //   34: ldc 231
    //   36: fcmpg
    //   37: ifge +43 -> 80
    //   40: aload_0
    //   41: getfield 19	de/atlogis/tilemapview/views/g:a	Lde/atlogis/tilemapview/views/RadarView;
    //   44: ldc 232
    //   46: invokestatic 235	de/atlogis/tilemapview/views/RadarView:a	(Lde/atlogis/tilemapview/views/RadarView;F)F
    //   49: pop
    //   50: aload_0
    //   51: aload_1
    //   52: invokespecial 237	de/atlogis/tilemapview/views/g:a	(Landroid/graphics/Canvas;)V
    //   55: aload_3
    //   56: monitorexit
    //   57: ldc2_w 238
    //   60: invokestatic 243	java/lang/Thread:sleep	(J)V
    //   63: aload_1
    //   64: ifnull -64 -> 0
    //   67: aload_0
    //   68: getfield 26	de/atlogis/tilemapview/views/g:b	Landroid/view/SurfaceHolder;
    //   71: aload_1
    //   72: invokeinterface 246 2 0
    //   77: goto -77 -> 0
    //   80: aload_0
    //   81: getfield 19	de/atlogis/tilemapview/views/g:a	Lde/atlogis/tilemapview/views/RadarView;
    //   84: ldc 73
    //   86: invokestatic 248	de/atlogis/tilemapview/views/RadarView:b	(Lde/atlogis/tilemapview/views/RadarView;F)F
    //   89: pop
    //   90: goto -40 -> 50
    //   93: astore_2
    //   94: aload_3
    //   95: monitorexit
    //   96: aload_2
    //   97: athrow
    //   98: astore_2
    //   99: aload_1
    //   100: ifnull +13 -> 113
    //   103: aload_0
    //   104: getfield 26	de/atlogis/tilemapview/views/g:b	Landroid/view/SurfaceHolder;
    //   107: aload_1
    //   108: invokeinterface 246 2 0
    //   113: aload_2
    //   114: athrow
    //   115: pop
    //   116: goto -53 -> 63
    //   119: return
    //   120: astore_2
    //   121: aconst_null
    //   122: astore_1
    //   123: goto -24 -> 99
    //
    // Exception table:
    //   from	to	target	type
    //   27	57	93	finally
    //   80	96	93	finally
    //   20	27	98	finally
    //   57	63	98	finally
    //   96	98	98	finally
    //   57	63	115	java/lang/InterruptedException
    //   7	18	120	finally
  }
}
