package org.outlander.views;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.EmbossMaskFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

public class CompassView extends c
  implements h
{
  private static final Path I;
  private static final String[] e;
  private static final int[] f;
  private static final String[] g;
  private static final int[] h;
  private boolean A = true;
  private int B;
  private boolean C;
  private int D;
  private final Path E;
  private float F = 1.0F;
  private final Path G;
  private float H;
  private j J;
  private boolean K;
  private float L = 0.9F;
  private long M;
  private boolean N;
  private final int i = -13408564;
  private final int j = -5425096;
  private final Paint k;
  private final Paint l;
  private final Paint m;
  private final Paint n;
  private final TextPaint o;
  private final Paint p = new Paint();
  private final Paint q;
  private final Paint r;
  private final Paint s;
  private final Paint t;
  private int u;
  private int v;
  private int w;
  private boolean x = true;
  private boolean y = true;
  private boolean z = true;

  static
  {
    Object[] localObject = new String[4];
    localObject[0] = "N";
    localObject[1] = "E";
    localObject[2] = "S";
    localObject[3] = "W";
    e = (String[])localObject;
    localObject = new int[8];
    localObject[0] = 30;
    localObject[1] = 30;
    localObject[2] = 60;
    localObject[3] = 30;
    localObject[4] = 60;
    localObject[5] = 30;
    localObject[6] = 60;
    localObject[7] = 30;
    f = (int[])localObject;
    localObject = new String[8];
    localObject[0] = "3";
    localObject[1] = "6";
    localObject[2] = "12";
    localObject[3] = "15";
    localObject[4] = "21";
    localObject[5] = "24";
    localObject[6] = "30";
    localObject[7] = "33";
    g = (String[])localObject;
    localObject = new int[12];
    localObject[0] = 15;
    localObject[1] = 30;
    localObject[2] = 30;
    localObject[3] = 30;
    localObject[4] = 30;
    localObject[5] = 30;
    localObject[6] = 30;
    localObject[7] = 30;
    localObject[8] = 30;
    localObject[9] = 30;
    localObject[10] = 30;
    localObject[11] = 30;
    h = (int[])localObject;
    I = b.a();
  }

  public CompassView(Context paramContext)
  {
    this(paramContext, null);
  }

  public CompassView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, true);
  }

  public CompassView(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean)
  {
    super(paramContext, paramBoolean);
    this.p.setColor(-4473925);
    this.p.setAntiAlias(true);
    this.p.setTextSize(12.0F);
    this.q = new Paint();
    this.q.setColor(-4473925);
    this.q.setAntiAlias(true);
    this.q.setTextSize(16.0F);
    this.k = new Paint();
    this.k.setAntiAlias(true);
    this.k.setColor(-13421773);
    this.k.setTextSize(20.0F);
    this.k.setStrokeWidth(1.5F);
    this.k.setTextAlign(Paint.Align.CENTER);
    Object localObject = Typeface.create(Typeface.MONOSPACE, 1);
    this.k.setTypeface((Typeface)localObject);
    this.l = new Paint();
    this.l.setStyle(Paint.Style.STROKE);
    this.l.setAntiAlias(true);
    this.l.setColor(-13421773);
    this.l.setTextSize(12.0F);
    this.l.setTextAlign(Paint.Align.CENTER);
    this.l.setTypeface((Typeface)localObject);
    this.o = new TextPaint();
    this.o.setAntiAlias(true);
    this.o.setTextSize(18.0F);
    this.o.setTypeface(Typeface.DEFAULT_BOLD);
    this.o.setStyle(Paint.Style.STROKE);
    this.o.setTextAlign(Paint.Align.CENTER);
    this.m = new Paint();
    this.m.setAntiAlias(true);
    this.m.setStyle(Paint.Style.FILL);
    this.n = new Paint();
    this.n.setColor(-938761736);
    this.n.setAntiAlias(true);
    this.n.setStyle(Paint.Style.FILL);
    if (!isInEditMode())
      this.n.setShadowLayer(2.0F, 1.0F, 1.0F, -2004318072);
    this.r = new Paint();
    this.r.setAntiAlias(true);
    this.r.setStrokeWidth(9.0F);
    this.r.setStyle(Paint.Style.STROKE);
    this.r.setColor(-13421773);
    if (!isInEditMode())
    {
      localObject = this.r;
      float[] arrayOfFloat = new float[3];
      arrayOfFloat[0] = 1.0F;
      arrayOfFloat[1] = 1.0F;
      arrayOfFloat[2] = 1.0F;
      ((Paint)localObject).setMaskFilter(new EmbossMaskFilter(arrayOfFloat, 0.4F, 10.0F, 8.2F));
    }
    this.s = new Paint();
    this.s.setStyle(Paint.Style.FILL);
    this.t = new Paint();
    this.t.setAntiAlias(true);
    this.t.setStyle(Paint.Style.FILL);
    this.t.setStrokeWidth(0.3F);
    this.t.setColor(-10066330);
    this.E = new Path();
    this.E.moveTo(-5.0F, 0.0F);
    this.E.lineTo(5.0F, 0.0F);
    this.E.lineTo(0.0F, 10.0F);
    this.E.lineTo(-5.0F, 0.0F);
    this.E.close();
    this.G = new Path();
    this.G.moveTo(-6.0F, 11.0F);
    this.G.lineTo(0.0F, 22.0F);
    this.G.lineTo(6.0F, 11.0F);
    this.G.lineTo(1.8F, 12.0F);
    this.G.lineTo(1.8F, 4.0F);
    this.G.lineTo(-1.8F, 4.0F);
    this.G.lineTo(-1.8F, 12.0F);
    this.G.close();
  }

  private void a(Canvas paramCanvas, int paramInt1, int paramInt2)
  {
    int i1 = 0;
    paramCanvas.drawCircle(paramInt1, paramInt2, this.u, this.s);
    paramCanvas.save(1);
    paramCanvas.rotate(this.B, paramInt1, paramInt2);
    int i2 = paramInt2 - this.u + this.v / 2;
    int i3 = (int)(i2 + this.w + 10.0F * this.F);
    for (int i5 = 0; ; i5++)
    {
      float f1;
      if (i5 >= e.length)
      {
        f1 = this.l.getTextSize();
        if (this.x);
        for (int i4 = 0; ; i4++)
        {
          if (i4 >= f.length)
          {
            if (this.z);
            while (true)
            {
              if (i1 >= h.length)
              {
                paramCanvas.restore();
                this.r.setColor(-6710887);
                paramCanvas.drawCircle(paramInt1, paramInt2, this.u, this.r);
                return;
              }
              paramCanvas.rotate(h[i1], paramInt1, paramInt2);
              paramCanvas.drawLine(paramInt1, i2, paramInt1, i2 + 4, this.l);
              i1++;
            }
          }
          paramCanvas.rotate(f[i4], paramInt1, paramInt2);
          paramCanvas.drawLine(paramInt1, i2, paramInt1, i2 + 10, this.l);
          if (!this.y)
            continue;
          paramCanvas.drawText(g[i4], paramInt1, f1 + (i2 + 12), this.l);
        }
      }
      paramCanvas.save(1);
      paramCanvas.translate(paramInt1, i2);
      paramCanvas.scale(this.F, this.F, 0.0F, 0.0F);
      Paint localPaint = this.m;
      int i6;
      if (i5 != 0)
        i6 = -13408564;
      else
        i6 = -5425096;
      localPaint.setColor(i6);
      paramCanvas.drawPath(this.E, this.m);
      paramCanvas.restore();
      paramCanvas.drawText(e[i5], paramInt1, f1, this.k);
      paramCanvas.rotate(90.0F, paramInt1, paramInt2);
    }
  }

  private void a(Canvas paramCanvas, int paramInt1, int paramInt2, int paramInt3)
  {
    paramCanvas.save(1);
    paramCanvas.translate(paramInt1, paramInt2);
    paramCanvas.scale(this.H, this.H, 0.0F, 0.0F);
    paramCanvas.rotate(180 + (this.D + this.B));
    paramCanvas.drawPath(this.G, this.n);
    paramCanvas.restore();
  }

  private void b(Canvas paramCanvas, int paramInt1, int paramInt2)
  {
    paramCanvas.save(3);
    paramCanvas.translate(paramInt1, paramInt2);
    paramCanvas.rotate(this.B, 0.0F, 0.0F);
    float f1 = 5.0F * this.F;
    paramCanvas.scale(f1, f1, 0.0F, 0.0F);
    paramCanvas.drawPath(I, this.t);
    paramCanvas.rotate(45.0F, 0.0F, 0.0F);
    paramCanvas.scale(0.7F, 0.7F, 0.0F, 0.0F);
    paramCanvas.drawPath(I, this.t);
    paramCanvas.restore();
    paramCanvas.drawCircle(paramInt1, paramInt2, 5.0F * this.F, this.s);
  }

  private void c(int paramInt)
  {
    if ((-paramInt != this.B) && (this.J != null))
    {
      if (!this.N)
      {
        this.J.sendEmptyMessage(0);
        this.N = true;
      }
      long l1 = System.currentTimeMillis();
      if (l1 - this.M >= 750L)
      {
        this.J.a = 0;
        this.J.b = this.B;
        int i1 = -paramInt;
        this.J.c = (i1 - this.J.b);
        this.M = l1;
      }
    }
  }

  public void aa(float paramFloat)
  {
  }

  public void aa(int paramInt)
  {
    this.C = true;
    this.D = paramInt;
  }

  public void aa(Object paramObject)
  {
    if ((paramObject instanceof CompassView))
    {
      CompassView localCompassView = (CompassView)paramObject;
      this.a = localCompassView.a;
      this.B = localCompassView.B;
      this.C = localCompassView.C;
      this.D = localCompassView.D;
    }
  }

  public boolean aa()
  {
    return this.d;
  }

  public void b(int paramInt)
  {
    if (!this.d)
    {
      if (!this.K)
        this.B = (-paramInt);
      else
        this.B = (int)(this.L * this.B + (1.0F - this.L) * paramInt);
    }
    else
      c(paramInt);
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if (this.J != null)
    {
      this.J.removeMessages(0);
      this.J = null;
    }
  }

  protected void onDraw(Canvas paramCanvas)
  {
    int i1 = getWidth() / 2;
    int i2 = getHeight() / 2;
    a(paramCanvas, i1, i2);
    b(paramCanvas, i1, i2);
    if (this.C)
      a(paramCanvas, i1, i2, this.D);
    if (this.A)
      a(paramCanvas);
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i2 = View.MeasureSpec.getSize(paramInt1);
    int i1 = View.MeasureSpec.getSize(paramInt2);
    int i4 = View.MeasureSpec.getMode(paramInt1);
    int i3 = View.MeasureSpec.getMode(paramInt2);
    if ((i4 != 1073741824) || (i3 == 1073741824));
    setMeasuredDimension(i2, i1);
  }

  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    int i1 = Math.min(paramInt1, paramInt2);
    int i4 = i1 / 2;
    this.v = (i1 / 25);
    this.r.setStrokeWidth(this.v);
    this.u = (i4 - this.v / 2);
    int i2 = paramInt1 / 2;
    int i3 = paramInt2 / 2;
    this.r.setShader(new LinearGradient(i2 + i4, i3 - i4, i2, i3, -14540254, -7829368, Shader.TileMode.MIRROR));
    this.s.setShader(new LinearGradient(i2 + i4, i3 - i4, i2, i3, -3888520, -730456, Shader.TileMode.MIRROR));
    boolean bool;
    if (i1 <= 100)
      bool = false;
    else
      bool = true;
    this.x = bool;
    if (i1 <= 200)
      bool = false;
    else
      bool = true;
    this.y = bool;
    if (i1 <= 150)
      bool = false;
    else
      bool = true;
    this.z = bool;
    this.w = (i1 / 10);
    this.k.setTextSize(this.w);
    this.l.setTextSize(i1 / 25.0F);
    this.l.setStrokeWidth(1.0F);
    this.F = Math.max(1.0F, i1 / 160.0F);
    this.H = Math.max(1.0F, i1 / 60.0F);
    if (i1 <= 100)
      i1 = 0;
    else
      i1 = 1;
    this.A = (i1 >0);
  }
}
