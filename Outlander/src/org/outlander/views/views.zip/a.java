package org.outlander.views;

public abstract interface a {
    public abstract void aa(int paramInt);

    public abstract void aa(f paramf);

    public abstract boolean aa();

    public abstract void b(int paramInt);

    public abstract boolean b();
}
